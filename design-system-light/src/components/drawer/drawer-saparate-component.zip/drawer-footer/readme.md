# sy-drawer-footer



<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description | Type                            | Default   |
| -------- | --------- | ----------- | ------------------------------- | --------- |
| `align`  | `align`   |             | `"center" \| "left" \| "right"` | `'right'` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
