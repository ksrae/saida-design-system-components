import { Component, h, Prop } from '@stencil/core';

@Component({
  tag: 'sy-drawer-footer',
  shadow: false,
  scoped: true,
  styleUrl: 'sy-drawer-footer.scss'
})
export class DrawerFooter {
  @Prop() align: 'left' | 'center' | 'right' = 'right';

  render() {
    return (
      <div class={{
        'drawer-footer-wrapper': true,
        [`align-${this.align}`]: true
      }}>
        <slot />
      </div>
    );
  }
}
