// src/components/drawer/drawer.tsx

import { Component, h, Prop, Element, Watch, Event, EventEmitter } from '@stencil/core';

export interface HTMLSyDrawerElement extends HTMLElement {
  maskless: boolean;
  preventClose: boolean;
  position: 'top' | 'left' | 'right' | 'bottom';
  size: 'small' | 'medium' | 'large' | 'custom';
  closable: boolean;
  open: boolean;
  customSize: number;
  opened: EventEmitter<void>;
  closed: EventEmitter<void>;
}

@Component({
  tag: 'sy-drawer',
  shadow: false,
  scoped: true,
  styleUrl: 'sy-drawer.scss'
})
export class Drawer {
  @Element() hostElement: HTMLSyDrawerElement;

  @Prop({ reflect: true }) maskless: boolean = false;
  @Prop({ reflect: true }) preventClose: boolean = false;
  @Prop({ reflect: true }) closable: boolean = false;
  @Prop({ mutable: true, reflect: true }) open: boolean = false;
  @Prop({ reflect: true }) customSize: number = 100;
  @Prop() position: 'top' | 'left' | 'right' | 'bottom' = 'right';
  @Prop() size: 'small' | 'medium' | 'large' | 'custom' = 'medium';

  @Event() opened: EventEmitter<void>;
  @Event() closed: EventEmitter<void>;

  private hasBeenAppendedToBody = false;

  constructor() {
    this.handleOutsideClick = this.handleOutsideClick.bind(this);
  }

  connectedCallback() {
    document.addEventListener('click', this.handleOutsideClick, true);
    // drawer 컴포넌트들에 자동으로 slot 설정
    this.setupDrawerComponentSlots();
    // drawer-header의 closed 이벤트 리스너 추가
    this.setupDrawerHeaderEvents();
  }

  disconnectedCallback() {
    document.removeEventListener('click', this.handleOutsideClick, true);
    
    // drawer-header 이벤트 리스너 제거
    const drawerHeader = this.hostElement.querySelector('sy-drawer-header');
    if (drawerHeader) {
      drawerHeader.removeEventListener('closed', this.handleHeaderClosed);
    }
    
    if (this.hasBeenAppendedToBody && document.body.contains(this.hostElement)) {
        document.body.removeChild(this.hostElement);
    }
  }

  private setupDrawerComponentSlots() {
    // drawer-header 자동 slot 설정
    const drawerHeader = this.hostElement.querySelector('sy-drawer-header');
    if (drawerHeader && !drawerHeader.getAttribute('slot')) {
      drawerHeader.setAttribute('slot', 'header');
    }

    // drawer-body 자동 slot 설정
    const drawerBody = this.hostElement.querySelector('sy-drawer-body');
    if (drawerBody && !drawerBody.getAttribute('slot')) {
      drawerBody.setAttribute('slot', 'body');
    }

    // drawer-footer 자동 slot 설정
    const drawerFooter = this.hostElement.querySelector('sy-drawer-footer');
    if (drawerFooter && !drawerFooter.getAttribute('slot')) {
      drawerFooter.setAttribute('slot', 'footer');
    }
  }

  private setupDrawerHeaderEvents() {
    const drawerHeader = this.hostElement.querySelector('sy-drawer-header');
    if (drawerHeader) {
      // 기존 이벤트 리스너 제거 (중복 방지)
      drawerHeader.removeEventListener('closed', this.handleHeaderClosed);
      // 새 이벤트 리스너 추가
      drawerHeader.addEventListener('closed', this.handleHeaderClosed);
    }
  }

  private handleHeaderClosed = () => {
    this.open = false;
  }

  componentDidLoad() {
    this.setupDrawerComponentSlots();
    this.setupDrawerHeaderEvents();
  }

  componentDidUpdate() {
    this.setupDrawerComponentSlots();
    this.setupDrawerHeaderEvents();
  }

  @Watch('open')
  handleOpenChange(newValue: boolean) {
    if (newValue) {
      this.appendToBody();
      this.opened.emit();
    } else {
      this.hostElement.removeAttribute('open');
      this.closed.emit();
    }
  }

  private appendToBody() {
    if (!this.hasBeenAppendedToBody) {
      document.body.appendChild(this.hostElement);
      this.hasBeenAppendedToBody = true;
    }
  }

  private handleOutsideClick(event: MouseEvent) {
    if (!this.open || this.preventClose) {
      return;
    }
    const container = this.hostElement.querySelector('.drawer-container');
    const path = event.composedPath();
    if (container && !path.includes(container)) {
      this.open = false;
    }
  }

  private handleMaskClick() {
    if (!this.preventClose) {
      this.open = false;
    }
  }

  private handleCloseButtonClick() {
    this.open = false;
  }

  private hasSlotContent(slotName: string): boolean {
    // 컴포넌트가 DOM에 완전히 연결된 후에만 쿼리하도록
    if (!this.hostElement.isConnected) return false;
    return !!this.hostElement.querySelector(`[slot="${slotName}"]`);
  }

  private getCustomSizeStyles() {
    if (this.size !== 'custom') {
      return {};
    }
    switch (this.position) {
      case 'left':
      case 'right':
        return { width: `${this.customSize}px` };
      case 'top':
      case 'bottom':
        return { height: `${this.customSize}px` };
      default:
        return {};
    }
  }

  render() {
    const hasHeader = this.hasSlotContent('header');
    const hasFooter = this.hasSlotContent('footer');

    const containerClasses = {
      'drawer-container': true,
      [this.position]: true,
      [this.size]: this.size !== 'custom',
    };

    return (
      <div class="drawer-wrapper">
        {!this.maskless && (
          <div class="drawer-mask" onClick={() => this.handleMaskClick()}></div>
        )}
        <div class={containerClasses} style={this.getCustomSizeStyles()}>
          {(this.closable || hasHeader) && (
            <div class="drawer-header">
              <slot name="header" />
              {this.closable && !hasHeader && (
                <div class="drawer-header-button-container">
                  <sy-icon selectable size="large" onClick={() => this.handleCloseButtonClick()}>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path fill="currentColor" d="M135.5 169C126.1 159.6 126.1 144.4 135.5 135.1C144.9 125.8 160.1 125.7 169.4 135.1L320.4 286.1L471.4 135.1C480.8 125.7 496 125.7 505.3 135.1C514.6 144.5 514.7 159.7 505.3 169L354.3 320L505.3 471C514.7 480.4 514.7 495.6 505.3 504.9C495.9 514.2 480.7 514.3 471.4 504.9L320.4 353.9L169.4 504.9C160 514.3 144.8 514.3 135.5 504.9C126.2 495.5 126.1 480.3 135.5 471L286.5 320L135.5 169z"/></svg>
                  </sy-icon>
                </div>
              )}
            </div>
          )}
          <div class="drawer-body">
            <slot name="body" />
          </div>
          {hasFooter && (
            <div class="drawer-footer">
              <slot name="footer" />
            </div>
          )}
        </div>
      </div>
    );
  }
}
