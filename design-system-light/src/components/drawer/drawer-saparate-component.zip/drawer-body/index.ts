export { DrawerBody } from './sy-drawer-body';
