import { Component, h, Prop } from '@stencil/core';

@Component({
  tag: 'sy-drawer-body',
  shadow: false,
  scoped: true,
  styleUrl: 'sy-drawer-body.scss'
})
export class DrawerBody {
  @Prop() scrollable: boolean = true;

  render() {
    return (
      <div class={{
        'drawer-body-wrapper': true,
        'scrollable': this.scrollable,
        'non-scrollable': !this.scrollable
      }}>
        <slot />
      </div>
    );
  }
}
