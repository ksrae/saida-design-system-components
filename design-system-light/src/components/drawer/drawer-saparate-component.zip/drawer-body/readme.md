# sy-drawer-body



<!-- Auto Generated Below -->


## Properties

| Property     | Attribute    | Description | Type      | Default |
| ------------ | ------------ | ----------- | --------- | ------- |
| `scrollable` | `scrollable` |             | `boolean` | `true`  |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
