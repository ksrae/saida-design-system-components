import { Component, h, Prop, Element, EventEmitter, Event } from '@stencil/core';

@Component({
  tag: 'sy-drawer-header',
  shadow: false,
  scoped: true,
  styleUrl: 'sy-drawer-header.scss'
})
export class DrawerHeader {
  @Element() hostElement: HTMLElement;

  @Prop() closable: boolean = false;
  @Event() closed: EventEmitter<void>;

  private handleCloseClick() {
    // 부모 drawer에게 close 이벤트를 전달
    this.closed.emit();
  }

  render() {
    return (
      <div class="drawer-header-wrapper">
        <div class="drawer-header-content">
          <slot />
        </div>
        {this.closable && (
          <div class="drawer-header-actions">
            <sy-icon selectable size="large" onClick={() => this.handleCloseClick()}>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640">
                <path fill="currentColor" d="M135.5 169C126.1 159.6 126.1 144.4 135.5 135.1C144.9 125.8 160.1 125.7 169.4 135.1L320.4 286.1L471.4 135.1C480.8 125.7 496 125.7 505.3 135.1C514.6 144.5 514.7 159.7 505.3 169L354.3 320L505.3 471C514.7 480.4 514.7 495.6 505.3 504.9C495.9 514.2 480.7 514.3 471.4 504.9L320.4 353.9L169.4 504.9C160 514.3 144.8 514.3 135.5 504.9C126.2 495.5 126.1 480.3 135.5 471L286.5 320L135.5 169z"/>
              </svg>
            </sy-icon>
          </div>
        )}
      </div>
    );
  }
}
